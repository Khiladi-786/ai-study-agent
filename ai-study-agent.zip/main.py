from fastapi import FastAPI
from google import genai
import os
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware

# Load environment variables
load_dotenv()

api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    raise ValueError("GOOGLE_API_KEY not found")

# Initialize Gemini client
client = genai.Client(api_key=api_key)

app = FastAPI()

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Home route
@app.get("/")
def home():
    return {"message": "AI Study Agent Running"}

# Ask AI
chat_history = []

@app.post("/ask")
async def ask_agent(data: Question):

    chat_history.append({"role":"user","content":data.question})

    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=data.question
    )

    answer = response.text

    chat_history.append({"role":"ai","content":answer})

    return {"answer":answer}